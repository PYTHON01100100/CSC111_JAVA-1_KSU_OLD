import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.List;
import java.util.concurrent.BlockingDeque;

public class ClientThread extends Thread{
	
	Server Server;
	Socket Client;
	List<ClientThread> Clients;
	BlockingDeque<String> commandStream;
	
	public ClientThread(Socket Client, List<ClientThread> Clients, BlockingDeque<String> commandStream) {
		this.Client = Client;
		this.Clients = Clients;
		this.commandStream = commandStream;
	}
	
	
	private void broadcast(String inputLine) {
		
		for(int i=0; i<Clients.size(); i++) {
			if(Clients.get(i) != null && Clients.get(i) != this) {
				try {
					OutputStream output = Clients.get(i).Client.getOutputStream();
					PrintWriter writer = new PrintWriter(output, true);
					writer.println(inputLine);
					System.out.println("sent: " + inputLine + " to: " + Clients.get(i).Client);
				} catch (IOException e) {
					System.out.println("Error with broadcasting to socket: " + Clients.get(i).Client);
				}
			}
		}
		
	}
	
	public void run() {
		System.out.println("Thread is running: " + Client.getInetAddress() + " - Local: " + Client.getLocalSocketAddress());
		try {
			while(!Client.isClosed()) {
				BufferedReader in = new BufferedReader(new InputStreamReader(Client.getInputStream()));
				String inputLine;
				while((inputLine = in.readLine()) != null) {
						System.out.println("attempting broadcast of: " + inputLine);
						broadcast(inputLine);
				}
			}
		} catch (Exception e) {
			System.out.println("error processing socket: " + Client);
			e.printStackTrace();
			return;
		}
		System.out.println("Client: " + Client + " Closed!");
	}
	
}

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.BlockingDeque;
import java.util.concurrent.LinkedBlockingDeque;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.StandardProtocolFamily;
import java.net.UnixDomainSocketAddress;
import java.nio.CharBuffer;
import java.nio.channels.ServerSocketChannel;
import java.nio.file.Path;

public class Main {
	
	public static void main(String[] args) {
		System.out.println("Hello world");
		Server server = null;
		try {
			server = new Server(2000);
		} catch (Exception e) {
			System.out.println("couldnt create server!");
			return;
		}
		
		List<Socket> clients = new ArrayList();
		int acceptedSocket = 0;
		final int maxClients = 20;
		List<ClientThread> clientThread = new ArrayList<>();
		BlockingDeque<String> commandStream = new LinkedBlockingDeque<String>();
		
		try {
			while(true) {
				InetAddress localHost = InetAddress.getLocalHost();
				System.out.println("accepting socket at: " + server.serverSocket + " address: " + localHost.getLocalHost());
				Socket clientSocket = server.acceptSocket();
				clients.add(clientSocket);
				System.out.println("accepted socket: " + clientSocket.getInetAddress());
				ClientThread thread = new ClientThread(clientSocket, clientThread, commandStream);
				thread.start();
				clientThread.add(thread);
				System.out.println("added socket to array!!!");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		for(ClientThread thread : clientThread) {
			try {
				thread.join();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		
		
		System.out.println("closed server");
	}

}

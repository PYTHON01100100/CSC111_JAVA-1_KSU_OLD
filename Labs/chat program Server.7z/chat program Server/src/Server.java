import java.net.ServerSocket;
import java.net.Socket;
import java.net.StandardProtocolFamily;
import java.net.UnixDomainSocketAddress;
import java.nio.channels.ServerSocketChannel;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.BlockingDeque;
import java.util.concurrent.LinkedBlockingDeque;

public class Server {
	
	int port;
	ServerSocket serverSocket;
	List<ClientThread> clientThreads;
	BlockingDeque<String> commandStream;
	
	public Server(int port) throws Exception{
		this.port = port;
		serverSocket = new ServerSocket(port);
		clientThreads = new ArrayList();
		commandStream = new LinkedBlockingDeque();
	}
	
	public Socket acceptSocket() {
		Socket client;
		try {
			client = serverSocket.accept();
		} catch (Exception e) {
			System.out.println("Error accepting socket!");
			return null;
		}
		return client;
	}
	
	private void closeServer() {
		while(serverSocket.isClosed()) {
			try {
				serverSocket.close();
			} catch (Exception e) {
				System.out.println("couldnt close socket");
			}
		}
	}
	
	public void launchNewClientThread(Socket Client) {
		clientThreads.add(new ClientThread(Client, clientThreads, commandStream));
	}
	
}

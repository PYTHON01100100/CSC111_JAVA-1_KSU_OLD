import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.Socket;

public class ServerMessagesThread extends Thread{
	
	Socket Client;
	BufferedReader in;
	
	public ServerMessagesThread(Socket Client) {
		this.Client = Client;
		in = null;
	}
	
	public void run() {
		
		try {
			in = new BufferedReader(new InputStreamReader(Client.getInputStream()));
			while(!Client.isClosed()) {
				String inputLine;
				while((inputLine = in.readLine()) != null) {
					System.out.println("attempting to recieve inputLine:");
					System.out.println(inputLine);
				}
			}
		} catch (Exception e) {
			System.out.println("error processing Server: " + Client);
			e.printStackTrace();
			return;
		}
		
	}
	
}

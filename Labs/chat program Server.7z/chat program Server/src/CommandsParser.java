import java.util.ArrayList;
import java.util.List;

public class CommandsParser {
	
	public enum CommandType{
		RENAME,
		GAME,
		WHISPER,
		ONLINE,
		CREATEGAME,
		HELP,
		EMOTE,
		NULL,
		GPT;
	}
	
	public String getFirstBoundedMatch(String input, char delimiter) {
		int end = 0;
		if(input.charAt(0) == delimiter) {
			for(int i=1; i<input.length(); i++) {
				if(input.charAt(i) == delimiter) {
					end = i;
					break;
				}
			}
		}
		if(end > 0)
			return "";
		String temp = "";
		for(int i=0; i<end+1; i++) {
			temp += input.charAt(i);
		}
		System.out.println(temp);
		return temp;
	}
	
	public CommandType commandType(String input) {
		String prefix = getFirstBoundedMatch(input, '!');
		System.out.println("prefix: " + prefix);
		CommandType type;
		switch(prefix) {
		
		case "!rename!":
			type = CommandType.RENAME;
			break;
			
		case "!game!":
			type = CommandType.GAME;
			break;
			
		case "!whisper!":
			type = CommandType.WHISPER;
			break;
			
		case "!online!":
			type = CommandType.ONLINE;
			break;
			
		case "!create game!":
			type = CommandType.CREATEGAME;
			break;
			
		case "!help!":
			type = CommandType.HELP;
			break;
			
		case "!emote!":
			type = CommandType.EMOTE;
			break;
		case "!GPT!":
			type = CommandType.GPT;
			default:
				type = CommandType.NULL;
				break;
		}
		return type;
	}
	
	public Command getCommand(String input) {
		Command temp = new Command();
		temp.type = commandType(input);
		
		switch(temp.type) {
		case RENAME:
			String newName = input.replaceAll("!rename!", "").trim();
			temp.commands.add("");
			break;
			
		case GAME:
			break;
			
		case WHISPER:
			break;
			
		case ONLINE:
			break;
			
		case CREATEGAME:
			break;
			
		case EMOTE:
			break;
		
		case GPT:
			break;
			
		case NULL:
			temp.commands.add("unkown command, the availale commands are:\n\n"
					+ "!rename!{new name}//changes the user's name to {new name}\n\n"
					+ "!game!{game name}!{game command}//sends {game command} to a program {game name} if found\n\n"
					+ "!whisper!{reciever name}!{message}//sends {message} to {reciever name} if found\n\n"
					+ "!online!//returns a list of every other connceted user\n\n"
					+ "!create game!{game name}!{game type}//creates a new program named {game name} of {game type}\n\n"
					+ "!emote!{emote name}//broadcasts ASCII emoticon {emote name} to other users");
			break;
			
			default:
				temp.commands.add("Unkown command error!!");
				break;
			
		}
		return temp;
	}
	
	private class Command{
		CommandType type;
		List<String> commands;
		
		public Command() {
			commands = new ArrayList<>();
		}
		
		public String toString() {
			String buffer = "";
			buffer += type + "\n";
			buffer += commands;
			return buffer;
		}
	}
	
	public static void main(String args[]) {
		CommandsParser cp = new CommandsParser();
		
		Command c = cp.getCommand("!rename!newName");
		
		System.out.println(c);
	}
	
}

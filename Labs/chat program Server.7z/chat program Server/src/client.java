import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.util.Scanner;

public class client {

	public static void main(String[] args) {
		
		Socket client = new Socket();
		
		Scanner input = new Scanner(System.in);
		
		String name;
		
		SocketAddress address = new InetSocketAddress("127.0.0.1", 2000);
		
		ServerMessagesThread inputThread = new ServerMessagesThread(client);
		
		try {
			client.connect(address, 500);
			name = client.toString();
			inputThread.start();
			OutputStream output = client.getOutputStream();
			PrintWriter writer = new PrintWriter(output, true);
			for(int i=0; i<10; i++) {
				String inputString = input.nextLine();
				if(inputString.equals("!exit!")) {
					System.out.println("exiting program");
					break;
				}else if(inputString.startsWith("!rename!")) {
					String newName = inputString.replaceFirst("!rename!", "").trim();
					if(newName.length() >= 3) {
						writer.println("User: " + name + " changed their name to: " + newName);
						name = newName;
					}else
						System.out.println("name too short, must be atleast 3 char long!!");
				}else
					writer.println(name + ": " + inputString);
			}
			client.close();
			inputThread.join();
			input.close();
		} catch (Exception e) {
			System.out.println("failed connect/send!");
			e.printStackTrace();
		}
		
	}

}
